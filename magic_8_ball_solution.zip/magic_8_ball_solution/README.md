#Magic 8-Ball Possible Solution

This is one possible solution to the Magic 8-Ball exercise. This project uses HTML, CSS, jQuery and the Animate CSS library.  

The JS code is well commented. Look through it and see what each line is doing.  Change some things and play around with it. Have fun!  

Solution and comments by Lee Richardson for General Assembly Los Angeles. 
